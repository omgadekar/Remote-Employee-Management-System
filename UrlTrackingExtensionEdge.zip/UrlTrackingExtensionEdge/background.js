var sentUrls = {};

setInterval(function() {
    chrome.tabs.query({}, function(tabs) {
        for (var i = 0; i < tabs.length; i++) {
            var url = tabs[i].url;
            if (!sentUrls[url]) {
                var time = new Date(); // Get the current time
                fetch(`http://localhost:5000/?url=${encodeURIComponent(url)}&time=${encodeURIComponent(time)}`);
                sentUrls[url] = true;
            }
        }
    });
}, 10000); // Adjust the interval as needed
